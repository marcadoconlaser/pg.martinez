import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { VectorTool, ToolCategory } from './types/vector';
import { INITIAL_VECTOR_TOOLS, CATEGORIES } from './data/vectorTools';
import { Header } from './components/Header';
import { CategoryNav } from './components/CategoryNav';
import { SearchBar } from './components/SearchBar';
import { ToolCard } from './components/ToolCard';
import { ToolDetailModal } from './components/ToolDetailModal';
import { AddToolModal } from './components/AddToolModal';
import { SvgInspector } from './components/SvgInspector';
import { MiniVectorizer } from './components/MiniVectorizer';
import { LaserTestGenerator } from './components/LaserTestGenerator';
import {
  Bookmark,
  Share2,
  Download,
  Search,
  Sparkles,
  Flame,
  Check,
} from 'lucide-react';

const STORAGE_KEY_CUSTOM_TOOLS = 'vectorhub_custom_tools_v1';
const STORAGE_KEY_FAVORITES = 'vectorhub_favorites_v1';
const STORAGE_KEY_DARK_MODE = 'vectorhub_dark_mode_v1';

export default function App() {
  // Theme state
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DARK_MODE);
      if (saved !== null) return JSON.parse(saved);
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      if (isDarkMode) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      localStorage.setItem(STORAGE_KEY_DARK_MODE, JSON.stringify(isDarkMode));
    } catch {
      // Ignore localStorage errors
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode((prev) => !prev);

  // Tab navigation
  const [activeTab, setActiveTab] = useState<'directory' | 'inspector' | 'vectorizer' | 'laser_matrix'>('directory');

  // Custom user tools in localStorage
  const [customTools, setCustomTools] = useState<VectorTool[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CUSTOM_TOOLS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Favorites
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FAVORITES);
      return saved ? JSON.parse(saved) : ['inkscape', 'svgomg', 'makercase', 'svgcode'];
    } catch {
      return ['inkscape', 'svgomg', 'makercase', 'svgcode'];
    }
  });

  const toggleFavorite = useCallback((toolId: string) => {
    setFavorites((prev) => {
      const next = prev.includes(toolId)
        ? prev.filter((id) => id !== toolId)
        : [...prev, toolId];
      try {
        localStorage.setItem(STORAGE_KEY_FAVORITES, JSON.stringify(next));
      } catch {
        // storage fallback
      }
      return next;
    });
  }, []);

  const handleAddTool = (tool: VectorTool) => {
    const updated = [tool, ...customTools];
    setCustomTools(updated);
    try {
      localStorage.setItem(STORAGE_KEY_CUSTOM_TOOLS, JSON.stringify(updated));
    } catch {
      // storage fallback
    }
  };

  // Combine initial + custom tools
  const allTools = useMemo(() => {
    return [...customTools, ...INITIAL_VECTOR_TOOLS];
  }, [customTools]);

  // Search & Filters
  const [selectedCategory, setSelectedCategory] = useState<ToolCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedFormat, setSelectedFormat] = useState<string>('all');
  const [filterWebOnly, setFilterWebOnly] = useState<boolean>(false);
  const [filterOpenSource, setFilterOpenSource] = useState<boolean>(false);
  const [filterLaserFriendly, setFilterLaserFriendly] = useState<boolean>(false);
  const [filterNoRegistration, setFilterNoRegistration] = useState<boolean>(false);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState<boolean>(false);

  // Modal states
  const [selectedToolForModal, setSelectedToolForModal] = useState<VectorTool | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [exportCopied, setExportCopied] = useState<boolean>(false);

  // Reset filters
  const handleResetFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setSelectedFormat('all');
    setFilterWebOnly(false);
    setFilterOpenSource(false);
    setFilterLaserFriendly(false);
    setFilterNoRegistration(false);
    setShowFavoritesOnly(false);
  };

  // Compute available formats
  const availableFormats = useMemo(() => {
    const fmts = new Set<string>();
    allTools.forEach((t) => t.formats.forEach((f) => fmts.add(f)));
    return Array.from(fmts).sort();
  }, [allTools]);

  // Compute counts per category
  const categoryCounts = useMemo(() => {
    const counts: Record<ToolCategory, number> = {
      all: allTools.length,
      editors: 0,
      vectorizers: 0,
      laser_cnc: 0,
      optimizers: 0,
      repositories: 0,
      converters: 0,
    };
    allTools.forEach((t) => {
      if (counts[t.category] !== undefined) {
        counts[t.category]++;
      }
    });
    return counts;
  }, [allTools]);

  // Filtered tools
  const filteredTools = useMemo(() => {
    return allTools.filter((tool) => {
      // Category filter
      if (selectedCategory !== 'all' && tool.category !== selectedCategory) {
        return false;
      }

      // Favorites only
      if (showFavoritesOnly && !favorites.includes(tool.id)) {
        return false;
      }

      // Quick filter: Web only
      if (filterWebOnly && !tool.platform.includes('Web')) {
        return false;
      }

      // Quick filter: Open source
      if (filterOpenSource && !tool.license.includes('Open Source')) {
        return false;
      }

      // Quick filter: Laser friendly
      if (filterLaserFriendly && !tool.laserFriendly) {
        return false;
      }

      // Quick filter: No registration
      if (filterNoRegistration && tool.requiresRegistration) {
        return false;
      }

      // Format filter
      if (selectedFormat !== 'all' && !tool.formats.includes(selectedFormat)) {
        return false;
      }

      // Search query filter (matches name, description, bestFor, tags, formats)
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = tool.name.toLowerCase().includes(q);
        const matchesShort = tool.shortDescription.toLowerCase().includes(q);
        const matchesBestFor = tool.bestFor.toLowerCase().includes(q);
        const matchesFormats = tool.formats.some((f) => f.toLowerCase().includes(q));
        const matchesTags = tool.tags.some((t) => t.toLowerCase().includes(q));

        if (!matchesName && !matchesShort && !matchesBestFor && !matchesFormats && !matchesTags) {
          return false;
        }
      }

      return true;
    });
  }, [
    allTools,
    selectedCategory,
    showFavoritesOnly,
    favorites,
    filterWebOnly,
    filterOpenSource,
    filterLaserFriendly,
    filterNoRegistration,
    selectedFormat,
    searchQuery,
  ]);

  // Export favorites as Markdown
  const handleExportMarkdown = () => {
    const favoriteTools = allTools.filter((t) => favorites.includes(t.id));
    let md = '# Mis Herramientas Vectoriales Guardadas\n\n';
    md += `*Exportado desde VectorHub el ${new Date().toLocaleDateString('es-ES')}*\n\n`;

    favoriteTools.forEach((t) => {
      md += `### [${t.name}](${t.url})\n`;
      md += `- **Categoría:** ${t.category}\n`;
      md += `- **Plataforma:** ${t.platform} · **Licencia:** ${t.license}\n`;
      md += `- **Formatos:** ${t.formats.join(', ')}\n`;
      md += `- **Ideal para:** ${t.bestFor}\n`;
      md += `- **Descripción:** ${t.shortDescription}\n\n`;
    });

    navigator.clipboard.writeText(md);
    setExportCopied(true);
    setTimeout(() => setExportCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Universal Top Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        favoritesCount={favorites.length}
        showFavoritesOnly={showFavoritesOnly}
        setShowFavoritesOnly={setShowFavoritesOnly}
        isDarkMode={isDarkMode}
        toggleDarkMode={toggleDarkMode}
        onOpenAddModal={() => setIsAddModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* TAB 1: DIRECTORY */}
        {activeTab === 'directory' && (
          <div className="space-y-6">
            
            {/* Hero Banner with editorial hierarchy (Zero-Pill discipline) */}
            <div className="relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 overflow-hidden shadow-sm">
              <div className="max-w-3xl space-y-3">
                <div className="flex items-center gap-2 text-xs text-indigo-600 dark:text-indigo-400 font-semibold tracking-wider uppercase">
                  <span>Directorio Curado de Recursos</span>
                  <span aria-hidden="true">·</span>
                  <span>100% Gratuitos y Open Source</span>
                </div>

                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight text-balance">
                  Herramientas Gratuitas para Trabajar con Vectores
                </h1>

                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                  Encuentra los mejores editores gráficos, vectorizadores automáticos de imágenes (raster a SVG/DXF), generadores para corte y grabado láser, optimizadores y repositorios de curvas limpias.
                </p>

                {/* Quick Highlights / Shortcuts */}
                <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-1.5 font-medium">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    <span>Sin marcas de agua ni pagos sorpresa</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-medium">
                    <Flame className="w-4 h-4 text-amber-500" />
                    <span>Optimizadas para corte láser y CNC</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Category Navigation */}
            <CategoryNav
              categories={CATEGORIES}
              selectedCategory={selectedCategory}
              onSelectCategory={(cat) => {
                setSelectedCategory(cat);
                setShowFavoritesOnly(false);
              }}
              categoryCounts={categoryCounts}
            />

            {/* Search and Filter Toolbar */}
            <SearchBar
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              selectedFormat={selectedFormat}
              setSelectedFormat={setSelectedFormat}
              filterWebOnly={filterWebOnly}
              setFilterWebOnly={setFilterWebOnly}
              filterOpenSource={filterOpenSource}
              setFilterOpenSource={setFilterOpenSource}
              filterLaserFriendly={filterLaserFriendly}
              setFilterLaserFriendly={setFilterLaserFriendly}
              filterNoRegistration={filterNoRegistration}
              setFilterNoRegistration={setFilterNoRegistration}
              totalResults={filteredTools.length}
              availableFormats={availableFormats}
              onResetFilters={handleResetFilters}
            />

            {/* Active filter banner when showing favorites only */}
            {showFavoritesOnly && (
              <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-xl flex items-center justify-between text-xs text-amber-900 dark:text-amber-200">
                <div className="flex items-center gap-2">
                  <Bookmark className="w-4 h-4 text-amber-600 fill-amber-500" />
                  <span>
                    Mostrando tus <strong>{favorites.length}</strong> herramientas marcadas como favoritas.
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportMarkdown}
                    className="px-2.5 py-1 bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-800 rounded-lg text-amber-900 dark:text-amber-300 font-medium hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors flex items-center gap-1"
                    title="Copiar lista de favoritos en formato Markdown"
                  >
                    {exportCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                    <span>{exportCopied ? '¡Copiado!' : 'Exportar lista (MD)'}</span>
                  </button>
                  <button
                    onClick={() => setShowFavoritesOnly(false)}
                    className="text-amber-800 dark:text-amber-300 underline font-semibold"
                  >
                    Ver todas
                  </button>
                </div>
              </div>
            )}

            {/* Tool Cards Grid */}
            {filteredTools.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredTools.map((tool) => (
                  <ToolCard
                    key={tool.id}
                    tool={tool}
                    isFavorite={favorites.includes(tool.id)}
                    onToggleFavorite={toggleFavorite}
                    onOpenDetails={(t) => setSelectedToolForModal(t)}
                  />
                ))}
              </div>
            ) : (
              /* Empty state */
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center max-w-lg mx-auto space-y-4">
                <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
                  <Search className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  No se encontraron herramientas con esos criterios
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Prueba a buscar con otro término, desmarcar los filtros rápidos o explorar todas las categorías.
                </p>
                <button
                  onClick={handleResetFilters}
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
                >
                  Restablecer todos los filtros
                </button>
              </div>
            )}

          </div>
        )}

        {/* TAB 2: SVG INSPECTOR */}
        {activeTab === 'inspector' && <SvgInspector />}

        {/* TAB 3: MINI VECTORIZER */}
        {activeTab === 'vectorizer' && (
          <MiniVectorizer
            onSendToInspector={() => {
              setActiveTab('inspector');
            }}
          />
        )}

        {/* TAB 4: LASER MATRIX GENERATOR */}
        {activeTab === 'laser_matrix' && (
          <LaserTestGenerator
            onSendToInspector={() => {
              setActiveTab('inspector');
            }}
          />
        )}

      </main>

      {/* Tool Detail Modal */}
      <ToolDetailModal
        tool={selectedToolForModal}
        onClose={() => setSelectedToolForModal(null)}
        isFavorite={selectedToolForModal ? favorites.includes(selectedToolForModal.id) : false}
        onToggleFavorite={toggleFavorite}
      />

      {/* Add Custom Tool Modal */}
      <AddToolModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddTool={handleAddTool}
      />

      {/* Minimal Footer (Clean copyright and actions, no fake telemetry) */}
      <footer className="mt-auto border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-6 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-900 dark:text-white">VectorHub</span>
            <span aria-hidden="true">·</span>
            <span>Recursos y herramientas vectoriales gratuitas para diseño y corte láser</span>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <button
              onClick={() => {
                setActiveTab('directory');
                setSelectedCategory('laser_cnc');
              }}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Corte Láser & CNC
            </button>
            <button
              onClick={() => {
                setActiveTab('directory');
                setSelectedCategory('vectorizers');
              }}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Vectorizadores
            </button>
            <button
              onClick={() => {
                setActiveTab('inspector');
              }}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Inspector SVG
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
