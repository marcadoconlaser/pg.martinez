import { VectorTool, CategoryInfo } from '../types/vector';

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'all',
    label: 'Todas las herramientas',
    description: 'Catálogo completo de utilidades vectoriales gratuitas y de código abierto',
  },
  {
    id: 'editors',
    label: 'Editores Vectoriales',
    description: 'Software y aplicaciones web para dibujar, diseñar trazados y editar SVG/DXF',
  },
  {
    id: 'vectorizers',
    label: 'Vectorizadores (Raster a Vector)',
    description: 'Convierte fotos, dibujos e imágenes JPG/PNG en curvas vectoriales limpias',
  },
  {
    id: 'laser_cnc',
    label: 'Corte Láser, Grabado & CNC',
    description: 'Generadores paramétricos de cajas, ensambles, engranajes y archivos para máquinas láser',
  },
  {
    id: 'optimizers',
    label: 'Optimizadores & Limpieza SVG',
    description: 'Reduce el peso de archivos, limpia nodos redundantes y repara trazados erróneos',
  },
  {
    id: 'repositories',
    label: 'Bancos de Vectores e Iconos',
    description: 'Millones de archivos SVG, DXF, siluetas y colecciones descargables sin costo',
  },
  {
    id: 'converters',
    label: 'Conversores de Formatos',
    description: 'Convierte entre SVG, DXF, EPS, PDF, CDR, AI y fuentes tipográficas a curvas',
  },
];

export const INITIAL_VECTOR_TOOLS: VectorTool[] = [
  // --- EDITORES VECTORIALES ---
  {
    id: 'inkscape',
    name: 'Inkscape',
    url: 'https://inkscape.org/',
    category: 'editors',
    shortDescription: 'El editor de gráficos vectoriales libre y de código abierto más potente y completo del mundo.',
    detailedDescription: 'Inkscape es el equivalente libre a Adobe Illustrator y CorelDRAW. Soporta estándares SVG al 100%, curvas Bézier de precisión, trazado automático de mapas de bits con Potrace integrado, manipulación de nodos, y un ecosistema gigante de extensiones para corte láser (G-code, exportador DXF R12, cajas, patrones).',
    bestFor: 'Diseño vectorial avanzado, preparación de archivos de corte láser y edición profesional sin licencias.',
    formats: ['SVG', 'DXF', 'PDF', 'EPS', 'PNG', 'HPGL'],
    platform: 'Windows / Mac / Linux',
    license: 'Código Abierto (Open Source)',
    requiresRegistration: false,
    laserFriendly: true,
    featured: true,
    tags: ['Editor', 'Open Source', 'Desktop', 'Láser', 'Curvas Bézier', 'Nodos'],
    tips: [
      'Usa "Trayecto > Descombinar" y "Trayecto > Unión" para fusionar siluetas antes de cortar con láser.',
      'Al exportar a DXF para máquinas láser, selecciona "DXF R12" para máxima compatibilidad con LightBurn y RDWorks.',
      'El atajo "F2" activa la herramienta de edición de nodos para afinar puntos de anclaje.'
    ]
  },
  {
    id: 'boxy-svg',
    name: 'Boxy SVG',
    url: 'https://boxy-svg.com/',
    category: 'editors',
    shortDescription: 'Editor web ultraligero y moderno que produce SVG limpios y sin código innecesario.',
    detailedDescription: 'Diseñado específicamente para generar código SVG puro y sin metadatos residuales. Su interfaz limpia emula la agilidad de Figma pero enfocada estrictamente en el estándar SVG. Ideal para crear iconos, tipografías vectoriales y piezas técnicas directamente en el navegador.',
    bestFor: 'Crear y retocar archivos SVG ligeros sin inflar el tamaño del archivo con metadatos extra.',
    formats: ['SVG', 'SVGZ', 'PNG', 'PDF', 'WebP'],
    platform: 'Web y Software',
    license: 'Plan Gratuito Generoso',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Editor Web', 'SVG Limpio', 'Ligero', 'Sin basura'],
    tips: [
      'Permite inspeccionar el árbol DOM del SVG en tiempo real para ver cada etiqueta <path> y <g>.',
      'Excelente para simplificar siluetas complejas que ralentizan el software de corte.'
    ]
  },
  {
    id: 'vectr',
    name: 'Vectr',
    url: 'https://vectr.com/',
    category: 'editors',
    shortDescription: 'Editor gráfico vectorial gratuito en la nube, intuitivo y con herramientas colaborativas.',
    detailedDescription: 'Una solución ágil para usuarios que necesitan diseñar formas vectoriales, logotipos básicos o esquemas sin instalar ningún software. Funciona fluido en cualquier navegador con sincronización instantánea y exportación directa en SVG y PNG.',
    bestFor: 'Principiantes que buscan una herramienta sin curva de aprendizaje empinada para trazar figuras rápidas.',
    formats: ['SVG', 'PNG', 'JPG'],
    platform: 'Web (En navegador)',
    license: 'Gratis con registro',
    requiresRegistration: true,
    laserFriendly: false,
    tags: ['Nube', 'Fácil', 'Colaborativo', 'Principiantes'],
    tips: [
      'Dispone de plantillas básicas de formas geométricas para crear placas y etiquetas en minutos.'
    ]
  },
  {
    id: 'method-draw',
    name: 'Method Draw',
    url: 'https://editor.method.ac/',
    category: 'editors',
    shortDescription: 'Editor SVG en navegador de código abierto, sin inicio de sesión ni publicidad intrusiva.',
    detailedDescription: 'Una versión refinada del clásico SVG-Edit. Carga en 1 segundo, no requiere crear cuenta ni registrarse. Te permite abrir cualquier archivo SVG arrastrándolo a la ventana, mover vectores, cambiar colores, unir trayectos y volver a descargar el SVG al instante.',
    bestFor: 'Abrir y hacer ajustes rápidos a un SVG desde cualquier computadora sin instalar nada.',
    formats: ['SVG', 'PNG'],
    platform: 'Web (En navegador)',
    license: 'Código Abierto (Open Source)',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Instantáneo', 'Sin Registro', 'Open Source', 'Rápido'],
    tips: [
      'Puedes usar "View > Source" para editar directamente el código XML del SVG si necesitas cambiar dimensiones o grosores.'
    ]
  },
  {
    id: 'vectorpea',
    name: 'Vectorpea',
    url: 'https://www.vectorpea.com/',
    category: 'editors',
    shortDescription: 'El hermano vectorial de Photopea: abre y edita archivos AI, EPS, SVG y PDF en la web.',
    detailedDescription: 'Creado por el desarrollador de Photopea, Vectorpea es un clon web de Adobe Illustrator capaz de abrir archivos nativos .AI de Illustrator, .CDR de CorelDRAW, .EPS y .PDF vectoriales directamente en tu navegador, sin pagar suscripción.',
    bestFor: 'Abrir archivos de clientes creados en Adobe Illustrator (.ai) o Corel (.cdr) cuando no tienes licencia instalada.',
    formats: ['AI', 'EPS', 'SVG', 'PDF', 'CDR', 'PNG'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    featured: true,
    tags: ['Abre AI', 'Abre CDR', 'Illustrator Web', 'Imprescindible'],
    tips: [
      'Guarda como SVG o PDF vectorial para importar directo en programas de corte CNC o láser.',
      'Soporta capas, modos de fusión y pluma de ancla idéntica a Adobe.'
    ]
  },

  // --- VECTORIZADORES (RASTER A VECTOR) ---
  {
    id: 'svgcode',
    name: 'SVGcode (PWA)',
    url: 'https://svgco.de/',
    category: 'vectorizers',
    shortDescription: 'Vectorizador PWA open-source que procesa imágenes 100% en tu navegador de forma privada.',
    detailedDescription: 'Construido por ingenieros de Google, SVGcode utiliza Potrace compilado a WebAssembly. A diferencia de otros sitios web, tus imágenes nunca se envían a ningún servidor externo. Permite vectorizar siluetas monocromáticas o multicolor con control fino de reducción de ruido, curvas y simplificación.',
    bestFor: 'Vectorizar firmas, siluetas, logos y dibujos escaneados con total privacidad y rapidez.',
    formats: ['SVG'],
    platform: 'Web (En navegador)',
    license: 'Código Abierto (Open Source)',
    requiresRegistration: false,
    laserFriendly: true,
    featured: true,
    tags: ['WebAssembly', '100% Privado', 'Sin Servidor', 'Open Source', 'Potrace'],
    tips: [
      'Para grabado láser en negro, reduce el número de colores a 2 para obtener contornos únicos y cerrados.',
      'Instálala como PWA en tu navegador para usarla sin conexión a internet.'
    ]
  },
  {
    id: 'vtracer',
    name: 'VTracer',
    url: 'https://www.visioncortex.org/vtracer/',
    category: 'vectorizers',
    shortDescription: 'Motor de visión artificial para convertir mapas de bits a vectores con curvas orgánicas suaves.',
    detailedDescription: 'Un software de trazado raster-a-vector de última generación desarrollado en Rust. A diferencia de los trazadores convencionales que generan miles de polígonos angulares, VTracer produce trazados suaves y curvas Bézier compactas que pesan mucho menos y cortan más fluido.',
    bestFor: 'Convertir fotografías complejas, bocetos artísticos e ilustraciones detalladas en vectores editables.',
    formats: ['SVG'],
    platform: 'Web y Software',
    license: 'Código Abierto (Open Source)',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Rust', 'Visión Artificial', 'Curvas Suaves', 'Alta Calidad'],
    tips: [
      'Usa el modo "Spline" para reducir la cantidad de nodos y acelerar el tiempo de corte en láseres CO2 o diodo.',
      'Ajusta el parámetro "Filter Speckle" para ignorar el grano sucio de fotos escaneadas.'
    ]
  },
  {
    id: 'autotracer',
    name: 'Autotracer.org',
    url: 'https://www.autotracer.org/',
    category: 'vectorizers',
    shortDescription: 'Conversor rápido de imágenes rasterizadas a SVG, DXF, EPS y PDF sin marca de agua.',
    detailedDescription: 'Herramienta clásica pero infalible que permite subir archivos PNG o JPG y descargarlos directamente en formato DXF o SVG. Permite filtrar ruido, ignorar fondos blancos y limitar la paleta de colores para conseguir trazados listos para manufactura.',
    bestFor: 'Generar archivos DXF directos a partir de logos o imágenes para software CAD o láser.',
    formats: ['DXF', 'SVG', 'EPS', 'PDF', 'FIG'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Genera DXF', 'Sin Registro', 'Gratis', 'CAD'],
    tips: [
      'Al seleccionar DXF como formato de salida, obtendrás directamente las líneas de corte para tu máquina.'
    ]
  },
  {
    id: 'picsvg',
    name: 'PicSVG',
    url: 'https://picsvg.com/',
    category: 'vectorizers',
    shortDescription: 'Conversor en línea muy sencillo para convertir fotos e imágenes a siluetas vectoriales SVG.',
    detailedDescription: 'PicSVG ofrece múltiples filtros de estilo (gran detalle, contornos finos, estilo sello, silueta dura). Es ideal cuando tienes una foto de un objeto, una mascota o un rostro y deseas convertirlo en un diseño vectorizado de alto contraste.',
    bestFor: 'Crear siluetas decorativas y sellos para grabar en madera, cuero o acrílico.',
    formats: ['SVG'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Siluetas', 'Fácil', 'Estilos', 'Grabado'],
    tips: [
      'Prueba el filtro "Outline" para obtener solo las líneas externas si vas a realizar corte perimetral.'
    ]
  },

  // --- HERRAMIENTAS PARA CORTE LÁSER & CNC ---
  {
    id: 'makercase',
    name: 'MakerCase',
    url: 'https://www.makercase.com/',
    category: 'laser_cnc',
    shortDescription: 'Generador web 3D de cajas con ensambles de dedo (finger joints) y cortes para láser y CNC.',
    detailedDescription: 'Una de las herramientas favoritas de la comunidad maker. Ingresas las dimensiones externas o internas de tu caja en milímetros, el grosor exacto de tu material (MDF, acrílico, contrachapado), el tipo de ensamble (plano o de dedos) y MakerCase genera el archivo SVG o DXF listo para cortar.',
    bestFor: 'Diseñar cajas, estuches, organizadores y gabinetes en segundos con compensación de corte.',
    formats: ['SVG', 'DXF'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    featured: true,
    tags: ['Cajas Láser', 'Corte Láser', 'Ensambles 3D', 'MDF', 'Madera', 'Acrílico'],
    tips: [
      '¡Atención al grosor del material!: Mide tu madera con un calibre/pie de rey en mm antes de generar la caja.',
      'Activa la compensación de corte (Kerf) según la lente de tu láser (habitualmente 0.1mm - 0.2mm).'
    ]
  },
  {
    id: 'boxes-py',
    name: 'Boxes.py',
    url: 'https://www.festi.info/boxes.py/',
    category: 'laser_cnc',
    shortDescription: 'El generador paramétrico de estructuras de madera y corte láser más avanzado de internet.',
    detailedDescription: 'Desarrollado en código abierto, Boxes.py incluye más de 80 modelos paramétricos: cajas con bisagras vivas (living hinges), cajoneras con guías, cajas redondas, engranajes, estantes modulares, portaherramientas y organizadores de piezas. Todo se calcula matemáticamente en base a tus medidas exactas.',
    bestFor: 'Proyectos avanzados de corte láser: bisagras flexibles de madera, cajones apilables y piezas complejas.',
    formats: ['SVG', 'DXF', 'PDF', 'PostScript', 'G-Code'],
    platform: 'Web (En navegador)',
    license: 'Código Abierto (Open Source)',
    requiresRegistration: false,
    laserFriendly: true,
    featured: true,
    tags: ['Bisagras Vivas', 'Organizadores', 'Paramétrico', 'Corte Láser', 'Imprescindible'],
    tips: [
      'Usa el modelo "TypeBox" o "FlexBox" para cajas con esquinas redondeadas y patrón de flexión de madera.',
      'Soporta compensación milimétrica de corte para un ensamble a presión sin necesidad de pegamento.'
    ]
  },
  {
    id: 'cuttle',
    name: 'Cuttle.xyz',
    url: 'https://cuttle.xyz/',
    category: 'laser_cnc',
    shortDescription: 'Entorno de diseño paramétrico vectorial enfocado en corte láser y manualidades digitales.',
    detailedDescription: 'Cuttle combina diseño vectorial con modificadores paramétricos (repeticiones radiales, ensambles ajustables, textos dinámicos). Su comunidad publica plantillas gratuitas para llaveros, adornos navideños, cajas y rompecabezas que puedes personalizar y descargar en SVG.',
    bestFor: 'Diseñar adornos personalizables, llaveros y patrones repetitivos con medidas dinámicas.',
    formats: ['SVG', 'DXF', 'PDF'],
    platform: 'Web (En navegador)',
    license: 'Plan Gratuito Generoso',
    requiresRegistration: true,
    laserFriendly: true,
    tags: ['Paramétrico', 'Plantillas', 'Llaveros', 'Artesanía Láser'],
    tips: [
      'Explora su sección "Templates" para encontrar cientos de archivos listos para cortar y cambiarles el nombre.'
    ]
  },
  {
    id: 'gear-generator',
    name: 'Gear Generator',
    url: 'https://geargenerator.com/',
    category: 'laser_cnc',
    shortDescription: 'Simulador y generador interactivo de engranajes y ruedas dentadas para cortar en láser o 3D.',
    detailedDescription: 'Crea trenes de engranajes reales, calcula relaciones de transmisión de velocidad, paso de diente y número de dientes. Permite animar el movimiento de los engranajes en pantalla para comprobar que engranan perfectamente antes de exportar el trazado vectorial.',
    bestFor: 'Mecanismos de madera, relojes mecánicos, autómatas y juguetes cinéticos cortados en láser.',
    formats: ['SVG', 'DXF'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Engranajes', 'Mecánica', 'Cinética', 'DXF'],
    tips: [
      'Verifica que el radio del eje central coincida exactamente con el vástago o varilla que vas a utilizar.'
    ]
  },
  {
    id: 'templatemaker',
    name: 'TemplateMaker',
    url: 'https://www.templatemaker.nl/es/',
    category: 'laser_cnc',
    shortDescription: 'Generador gratuito de plantillas de packaging, cajas de regalo y estuches de cartulina.',
    detailedDescription: 'Crea plantillas vectoriales a medida para doblar cajas de cartón, cartulina, papel y materiales delgados. Incluye cajas piramidales, trapezoidales, cajas de bombones, sobres y tubos. Descarga las líneas de corte y líneas de plegado (marcado) en capas separadas.',
    bestFor: 'Packaging personalizado, cajas para envíos de productos grabados con láser y estuches.',
    formats: ['SVG', 'DXF', 'PDF'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Packaging', 'Cajas Cartón', 'Plegado', 'Estuches'],
    tips: [
      'Asigna una potencia baja de grabado a las líneas de doblez y potencia alta a las líneas de corte.'
    ]
  },

  // --- OPTIMIZADORES & LIMPIEZA DE SVG ---
  {
    id: 'svgomg',
    name: 'SVGOMG (SVGO GUI)',
    url: 'https://jakearchibald.github.io/svgomg/',
    category: 'optimizers',
    shortDescription: 'El mejor optimizador de archivos SVG web: reduce el peso hasta un 80% y limpia nodos.',
    detailedDescription: 'Creado por Jake Archibald, es la interfaz gráfica oficial para SVGO. Elimina metadatos ocultos de software como Illustrator o Inkscape, redondea decimales superfluos, fusiona trazados adyacentes y elimina elementos invisibles, haciendo que las máquinas lean el archivo mucho más rápido.',
    bestFor: 'Limpiar archivos antes de mandarlos al láser o subirlos a la web para evitar retrasos y fallos de memoria.',
    formats: ['SVG'],
    platform: 'Web (En navegador)',
    license: 'Código Abierto (Open Source)',
    requiresRegistration: false,
    laserFriendly: true,
    featured: true,
    tags: ['Optimización', 'Reduce Peso', 'Limpia Nodos', 'Open Source', 'Esencial'],
    tips: [
      'Activa la vista "Prettify code" para verificar que los nombres de grupos o identificadores se mantengan limpios.',
      'Controla la precisión de decimales (normalmente 2 o 3 es ideal para milímetros exactos).'
    ]
  },
  {
    id: 'svg-path-visualizer',
    name: 'SVG Path Visualizer',
    url: 'https://svg-path-visualizer.netlify.app/',
    category: 'optimizers',
    shortDescription: 'Inspecciona, descompone y comprende cada comando Bézier (M, C, L, Z) de una ruta SVG.',
    detailedDescription: 'Una utilidad didáctica y técnica fantástica. Pegas el atributo d="M..." de cualquier trazado y te muestra de forma interactiva dónde empieza cada punto, sus tiradores tangenciales, arcos y puntos de control. Esencial para depurar vectores que dan errores de geometría abierta.',
    bestFor: 'Comprender por qué un trazado no se cierra o localizar nodos duplicados que arruinan un corte.',
    formats: ['SVG'],
    platform: 'Web (En navegador)',
    license: 'Código Abierto (Open Source)',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Debug', 'Comandos Path', 'Inspección', 'Nodos'],
    tips: [
      'Si una letra o figura no se corta como una sola pieza, revisa si el comando final termina en "Z" (cierre de ruta).'
    ]
  },
  {
    id: 'svgviewer',
    name: 'SVGViewer.dev',
    url: 'https://www.svgviewer.dev/',
    category: 'optimizers',
    shortDescription: 'Visor, editor de código, conversor y limpiador de SVG todo-en-uno en tu navegador.',
    detailedDescription: 'Permite visualizar el SVG, editar el código fuente con coloreado de sintaxis, previsualizarlo sobre fondo oscuro o claro, cambiar el grosor de línea y convertirlo instantáneamente a React/JSX o PNG de alta resolución.',
    bestFor: 'Inspeccionar rápidamente archivos SVG descargados y cambiarles color o tamaño al instante.',
    formats: ['SVG', 'PNG', 'JSX'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: false,
    tags: ['Visor', 'Editor de Código', 'Conversor', 'Web'],
    tips: [
      'Copia el código SVG al portapapeles con un solo clic para pegarlo directamente en Inkscape o LightBurn.'
    ]
  },

  // --- REPOSITORIOS Y BANCOS DE VECTORES ---
  {
    id: 'svgrepo',
    name: 'SVG Repo',
    url: 'https://www.svgrepo.com/',
    category: 'repositories',
    shortDescription: 'Más de 500.000 vectores e iconos SVG de código abierto con licencia para uso comercial.',
    detailedDescription: 'El repositorio de SVG más limpio y directo de internet. Sin cuentas obligatorias, sin captchas pesados. Cada icono o vector se puede descargar en SVG puro o editarle los colores directamente en el visor web antes de descargarlo.',
    bestFor: 'Encontrar iconos, siluetas temáticas, símbolos técnicos y pictogramas listos para grabar.',
    formats: ['SVG', 'PNG'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    featured: true,
    tags: ['500k+ Vectores', 'Uso Comercial', 'Iconos', 'Siluetas', 'Directo'],
    tips: [
      'Filtra por "Monocolor" para encontrar siluetas perfectas para grabado láser en metales o madera.'
    ]
  },
  {
    id: 'undraw',
    name: 'unDraw',
    url: 'https://undraw.co/illustrations',
    category: 'repositories',
    shortDescription: 'Ilustraciones vectoriales modernas de libre uso con selector de color hexadecimal en vivo.',
    detailedDescription: 'Creado por Katerina Limpitsouni, unDraw ofrece una inmensa colección de ilustraciones vectoriales que puedes utilizar en proyectos personales y comerciales sin atribución requerida. Su selector de color te permite cambiar toda la gama cromática antes de descargar el SVG.',
    bestFor: 'Ilustraciones para proyectos gráficos, placas conmemorativas y diseños modernos.',
    formats: ['SVG', 'PNG'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: false,
    tags: ['Ilustraciones', 'Libre Atribución', 'Color en Vivo'],
    tips: [
      'Pon el selector de color en negro (#000000) si planeas usar las ilustraciones para serigrafía o grabado.'
    ]
  },
  {
    id: 'threeaxis',
    name: '3axis.co',
    url: 'https://3axis.co/',
    category: 'repositories',
    shortDescription: 'El mayor repositorio mundial de vectores gratuitos específicos para corte láser y CNC.',
    detailedDescription: 'Miles de diseños compartidos por la comunidad maker: paneles celosía decorativos, relojes de pared, lámparas 3D armables, mandalas multicapa, rompecabezas y cajas listos para cortar. Todos los archivos están organizados por categorías y disponibles en DXF, CDR y SVG.',
    bestFor: 'Descargar proyectos completos de corte láser listos para mandar a la máquina (decoración, celosías, mandalas).',
    formats: ['DXF', 'SVG', 'CDR', 'DWG'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    featured: true,
    tags: ['Corte Láser', 'Mandalas', 'Celosías', 'DXF', 'Lámparas 3D', 'CNC'],
    tips: [
      'Comprueba siempre las medidas y grosor de ranuras de ensamble en tu software antes de cortar la madera.',
      'Muchos archivos vienen en formato CDR (Corel); puedes abrirlos gratis con Vectorpea.'
    ]
  },
  {
    id: 'iconify',
    name: 'Iconify',
    url: 'https://icon-sets.iconify.design/',
    category: 'repositories',
    shortDescription: 'Más de 200.000 iconos unificados de todas las colecciones principales en SVG limpio.',
    detailedDescription: 'Agrupa bibliotecas como Material Design, FontAwesome, Lucide, Tabler y muchas más en un solo motor de búsqueda veloz. Permite rotar, voltear y descargar cada icono en SVG optimizado sin envoltorios pesados.',
    bestFor: 'Encontrar señalética, pictogramas industriales y símbolos normalizados para rotulación.',
    formats: ['SVG', 'PNG', 'JSON', 'CSS'],
    platform: 'Web (En navegador)',
    license: 'Código Abierto (Open Source)',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Iconos', 'Señalética', '200k+', 'Open Source'],
    tips: [
      'Al buscar símbolos industriales (peligro, alta tensión, reciclaje), usa palabras clave en inglés para más resultados.'
    ]
  },

  // --- CONVERSORES DE FORMATOS ---
  {
    id: 'cloudconvert-vector',
    name: 'CloudConvert Vector',
    url: 'https://cloudconvert.com/vector-converter',
    category: 'converters',
    shortDescription: 'Conversor en la nube de alta fidelidad entre SVG, DXF, EPS, PDF, AI, CDR y WMF.',
    detailedDescription: 'Soporta más de 200 formatos. Conserva las curvas y capas vectoriales al convertir entre formatos propietarios (como Illustrator AI o Corel CDR) hacia formatos estándar abiertos como DXF y SVG. Cuenta con 25 conversiones gratuitas diarias.',
    bestFor: 'Convertir archivos que tu máquina o software de diseño no puede abrir directamente.',
    formats: ['SVG', 'DXF', 'EPS', 'PDF', 'AI', 'CDR'],
    platform: 'Web (En navegador)',
    license: 'Plan Gratuito Generoso',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['Conversor', 'DXF a SVG', 'AI a DXF', 'CDR a SVG'],
    tips: [
      'Excelente cuando un cliente te entrega un archivo en .CDR y necesitas pasarlo a .DXF para corte.'
    ]
  },
  {
    id: 'calligraphr',
    name: 'Calligraphr',
    url: 'https://www.calligraphr.com/es/',
    category: 'converters',
    shortDescription: 'Convierte tu propia caligrafía o dibujos a fuentes tipográficas vectoriales TTF/OTF.',
    detailedDescription: 'Permite imprimir o rellenar una plantilla digital con tus letras, escanearla o subirla, y el sistema vectoriza automáticamente cada carácter para crear una tipografía instalable en tu sistema operativo.',
    bestFor: 'Crear firmas personalizadas o fuentes manuscritas para grabar nombres en regalos.',
    formats: ['TTF', 'OTF', 'SVG'],
    platform: 'Web (En navegador)',
    license: 'Plan Gratuito Generoso',
    requiresRegistration: true,
    laserFriendly: true,
    tags: ['Tipografías', 'Caligrafía', 'Firmas', 'TTF'],
    tips: [
      'Una vez instalada la fuente, puedes escribir cualquier nombre en tu programa de corte como texto editable.'
    ]
  },
  {
    id: 'dxf2svg',
    name: 'Convertio DXF a SVG',
    url: 'https://convertio.co/es/dxf-svg/',
    category: 'converters',
    shortDescription: 'Conversor directo de archivos CAD (DXF y DWG) a SVG visualizable en cualquier pantalla.',
    detailedDescription: 'Permite transformar planos de arquitectura o piezas mecánicas diseñadas en AutoCAD en gráficos vectoriales ligeros en formato SVG para visualizarlos o editarlos en programas de diseño gráfico.',
    bestFor: 'Visualizar planos técnicos DXF sin necesidad de tener instalado software pesado de CAD.',
    formats: ['DXF', 'SVG', 'DWG', 'PDF'],
    platform: 'Web (En navegador)',
    license: 'Gratis sin registro',
    requiresRegistration: false,
    laserFriendly: true,
    tags: ['CAD', 'DXF', 'AutoCAD', 'Conversión'],
    tips: [
      'Ideal para extraer el contorno de piezas de ingeniería para corte rápido.'
    ]
  }
];
