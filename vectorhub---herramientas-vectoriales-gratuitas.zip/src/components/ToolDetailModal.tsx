import React, { useEffect, useState } from 'react';
import { VectorTool } from '../types/vector';
import {
  X,
  ExternalLink,
  Bookmark,
  Copy,
  Check,
  Flame,
  Globe,
  Monitor,
  Lightbulb,
  FileCheck,
  ShieldCheck,
} from 'lucide-react';

interface ToolDetailModalProps {
  tool: VectorTool | null;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
}

export const ToolDetailModal: React.FC<ToolDetailModalProps> = ({
  tool,
  onClose,
  isFavorite,
  onToggleFavorite,
}) => {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!tool) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(tool.url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
              <span className="font-medium text-indigo-600 dark:text-indigo-400 uppercase tracking-wider text-[11px]">
                {tool.category}
              </span>
              <span aria-hidden="true">·</span>
              <span>{tool.platform}</span>
              {tool.laserFriendly && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-600 dark:text-amber-400 font-medium flex items-center gap-1">
                    <Flame className="w-3 h-3" />
                    Corte Láser / CNC
                  </span>
                </>
              )}
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white">
              {tool.name}
            </h2>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={() => onToggleFavorite(tool.id)}
              className="p-2 text-slate-400 hover:text-amber-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Guardar en favoritos"
            >
              <Bookmark className={`w-5 h-5 ${isFavorite ? 'fill-amber-500 text-amber-500' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-600 dark:text-slate-300">
          
          {/* Main detailed description */}
          <div>
            <h4 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-2">
              Descripción completa
            </h4>
            <p className="leading-relaxed">
              {tool.detailedDescription}
            </p>
          </div>

          {/* Best for box */}
          <div className="p-3.5 bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 rounded-xl">
            <span className="font-semibold text-indigo-950 dark:text-indigo-200 text-xs block mb-1">
              ¿Para qué situaciones es la mejor opción?
            </span>
            <p className="text-indigo-900 dark:text-indigo-300 text-xs leading-relaxed">
              {tool.bestFor}
            </p>
          </div>

          {/* Technical Specs grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-400 block mb-1 flex items-center gap-1.5">
                <FileCheck className="w-3.5 h-3.5 text-indigo-500" />
                Formatos soportados
              </span>
              <span className="font-mono text-xs font-semibold text-slate-900 dark:text-slate-100">
                {tool.formats.join(', ')}
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-400 block mb-1 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                Licencia
              </span>
              <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                {tool.license}
              </span>
            </div>

            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800">
              <span className="text-xs text-slate-400 block mb-1 flex items-center gap-1.5">
                {tool.platform.includes('Web') ? <Globe className="w-3.5 h-3.5 text-cyan-500" /> : <Monitor className="w-3.5 h-3.5 text-slate-500" />}
                Requisitos
              </span>
              <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                {tool.requiresRegistration ? 'Requiere cuenta gratuita' : 'Sin registro (Directo)'}
              </span>
            </div>
          </div>

          {/* Practical Tips */}
          {tool.tips && tool.tips.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-amber-500" />
                Consejos y trucos de uso
              </h4>
              <ul className="space-y-2">
                {tool.tips.map((tip, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                    <span className="font-mono text-indigo-500 dark:text-indigo-400 font-bold">
                      {idx + 1}.
                    </span>
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Official URL display */}
          <div className="pt-2">
            <span className="text-xs text-slate-400 block mb-1.5">Enlace oficial del recurso:</span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={tool.url}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-slate-600 dark:text-slate-300 select-all"
              />
              <button
                onClick={handleCopyLink}
                className="px-3 py-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors whitespace-nowrap"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copiado' : 'Copiar'}</span>
              </button>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg transition-colors"
          >
            Cerrar ventana
          </button>

          <a
            href={tool.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors whitespace-nowrap"
          >
            <span>Abrir {tool.name}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
