import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Wand2,
  Upload,
  Download,
  Copy,
  Check,
  Flame,
  ArrowRight,
  Sliders,
  Maximize2,
} from 'lucide-react';

interface MiniVectorizerProps {
  onSendToInspector: (svgString: string) => void;
}

export const MiniVectorizer: React.FC<MiniVectorizerProps> = ({ onSendToInspector }) => {
  const [threshold, setThreshold] = useState<number>(128);
  const [invert, setInvert] = useState<boolean>(false);
  const [outputMode, setOutputMode] = useState<'fill' | 'stroke'>('fill');
  const [generatedSvg, setGeneratedSvg] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [activePreset, setActivePreset] = useState<string>('wolf');
  const [imageLoaded, setImageLoaded] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Draw preset onto canvas
  const loadPreset = useCallback((type: string) => {
    setActivePreset(type);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 300;
    canvas.height = 300;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, 300, 300);
    ctx.fillStyle = '#000000';

    if (type === 'wolf') {
      // Draw a sharp howling silhouette
      ctx.beginPath();
      ctx.moveTo(150, 40);
      ctx.lineTo(135, 75);
      ctx.lineTo(110, 80);
      ctx.lineTo(130, 105);
      ctx.lineTo(105, 140);
      ctx.lineTo(135, 150);
      ctx.lineTo(120, 200);
      ctx.lineTo(90, 220);
      ctx.lineTo(90, 260);
      ctx.lineTo(130, 260);
      ctx.lineTo(145, 220);
      ctx.lineTo(170, 260);
      ctx.lineTo(210, 260);
      ctx.lineTo(200, 190);
      ctx.lineTo(215, 160);
      ctx.lineTo(195, 130);
      ctx.lineTo(210, 95);
      ctx.lineTo(175, 90);
      ctx.lineTo(165, 40);
      ctx.closePath();
      ctx.fill();

      // Eye slit
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(150, 80, 5, 0, Math.PI * 2);
      ctx.fill();
    } else if (type === 'signature') {
      // Signature curve
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 9;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(40, 160);
      ctx.bezierCurveTo(90, 70, 110, 220, 160, 130);
      ctx.bezierCurveTo(180, 80, 220, 180, 260, 140);
      ctx.stroke();

      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(60, 210);
      ctx.lineTo(240, 210);
      ctx.stroke();
    } else {
      // Gear / Mechanical Key
      ctx.beginPath();
      ctx.rect(50, 135, 200, 30);
      ctx.arc(70, 150, 35, 0, Math.PI * 2);
      ctx.rect(180, 165, 20, 35);
      ctx.rect(215, 165, 20, 25);
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(70, 150, 16, 0, Math.PI * 2);
      ctx.fill();
    }

    setImageLoaded(true);
  }, []);

  // Vectorize canvas using marching segments / run-length horizontal span path generation
  const processVectorization = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const imgData = ctx.getImageData(0, 0, width, height);
    const data = imgData.data;

    // Create a 2D binary grid
    const binary = new Uint8Array(width * height);
    for (let i = 0; i < data.length; i += 4) {
      // Luminance formula
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      const isBlack = invert ? lum >= threshold : lum < threshold;
      binary[i / 4] = isBlack ? 1 : 0;
    }

    // Build contiguous horizontal spans into vector rectangles or simplified polygon paths
    let pathD = '';
    for (let y = 0; y < height; y++) {
      let inSpan = false;
      let startX = 0;
      for (let x = 0; x < width; x++) {
        const val = binary[y * width + x];
        if (val === 1 && !inSpan) {
          inSpan = true;
          startX = x;
        } else if (val === 0 && inSpan) {
          inSpan = false;
          pathD += `M${startX},${y}H${x}v1H${startX}Z `;
        }
      }
      if (inSpan) {
        pathD += `M${startX},${y}H${width}v1H${startX}Z `;
      }
    }

    const strokeColor = '#DC2626';
    const fillColor = '#0F172A';

    const svgResult = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
  <!-- Generado con VectorHub Express Vectorizer -->
  <path d="${pathD}" ${
      outputMode === 'fill'
        ? `fill="${fillColor}" stroke="none"`
        : `fill="none" stroke="${strokeColor}" stroke-width="0.8"`
    } />
</svg>`;

    setGeneratedSvg(svgResult);
  }, [threshold, invert, outputMode]);

  useEffect(() => {
    loadPreset('wolf');
  }, [loadPreset]);

  useEffect(() => {
    if (imageLoaded) {
      processVectorization();
    }
  }, [imageLoaded, processVectorization]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = canvasRef.current;
          if (!canvas) return;
          const ctx = canvas.getContext('2d');
          if (!ctx) return;

          // Scale proportionally to max 320px
          const maxDim = 320;
          let w = img.width;
          let h = img.height;
          if (w > maxDim || h > maxDim) {
            if (w > h) {
              h = Math.round((h * maxDim) / w);
              w = maxDim;
            } else {
              w = Math.round((w * maxDim) / h);
              h = maxDim;
            }
          }

          canvas.width = w;
          canvas.height = h;
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, w, h);
          ctx.drawImage(img, 0, 0, w, h);
          setActivePreset('custom');
          setImageLoaded(true);
          processVectorization();
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCopySvg = () => {
    navigator.clipboard.writeText(generatedSvg);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadSvg = () => {
    const blob = new Blob([generatedSvg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vectorized_${Date.now()}.svg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Mini-Vectorizador Express (Raster a SVG)</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Convierte mapas de bits (PNG, JPG) en trazados vectoriales limpios directamente en tu navegador, sin subir imágenes a ningún servidor.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Upload className="w-4 h-4 text-indigo-500" />
            <span>Subir mi imagen</span>
          </button>

          <button
            onClick={handleCopySvg}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copiado' : 'Copiar SVG'}</span>
          </button>

          <button
            onClick={handleDownloadSvg}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Descargar SVG</span>
          </button>
        </div>
      </div>

      {/* Control Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          
          {/* Presets */}
          <div className="flex items-center gap-1 text-xs">
            <span className="text-slate-400 font-medium mr-1">Ejemplos para probar:</span>
            <button
              onClick={() => loadPreset('wolf')}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                activePreset === 'wolf'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Silueta de Lobo (Grabado)
            </button>
            <button
              onClick={() => loadPreset('signature')}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                activePreset === 'signature'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Firma Caligráfica
            </button>
            <button
              onClick={() => loadPreset('key')}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                activePreset === 'key'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Llave Técnica
            </button>
          </div>

          {/* Mode Switcher: Fill (engrave) vs Stroke (laser cut) */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-medium">Modo de salida:</span>
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg">
              <button
                onClick={() => setOutputMode('fill')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors ${
                  outputMode === 'fill'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Relleno (Grabado Láser)
              </button>
              <button
                onClick={() => setOutputMode('stroke')}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors flex items-center gap-1 ${
                  outputMode === 'stroke'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                <Flame className="w-3 h-3 text-amber-500" />
                <span>Líneas (Corte Láser)</span>
              </button>
            </div>
          </div>

        </div>

        {/* Sliders: Threshold & Invert */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-indigo-500" />
                Umbral de Binarización (Threshold)
              </span>
              <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
                {threshold} / 255
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="254"
              value={threshold}
              onChange={(e) => setThreshold(Number(e.target.value))}
              className="w-full accent-indigo-600 cursor-pointer"
            />
            <span className="text-[11px] text-slate-400 block">
              Mueve hacia la derecha para capturar más trazos oscuros o hacia la izquierda para limpiar ruido.
            </span>
          </div>

          <div className="flex items-center justify-between sm:justify-end gap-6 pt-2 sm:pt-0">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={invert}
                onChange={(e) => setInvert(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
              />
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                Invertir blanco / negro
              </span>
            </label>

            <button
              onClick={() => onSendToInspector(generatedSvg)}
              className="px-3 py-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 rounded-lg border border-indigo-200 dark:border-indigo-900 flex items-center gap-1.5 transition-colors"
            >
              <span>Abrir en Inspector</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Comparison Grid: Bitmap Original vs Vector Result */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Left: Original Bitmap Canvas */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col">
          <div className="flex items-center justify-between mb-3 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              1. Imagen Original (Raster)
            </span>
            <span className="text-slate-400 text-[11px]">Píxeles y resolución fija</span>
          </div>
          <div className="flex-1 min-h-[300px] bg-slate-50 dark:bg-slate-950 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 overflow-hidden">
            <canvas
              ref={canvasRef}
              className="max-w-full max-h-[280px] object-contain shadow-sm border border-slate-200 dark:border-slate-700 rounded"
            />
          </div>
        </div>

        {/* Right: Vectorized SVG Output */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col">
          <div className="flex items-center justify-between mb-3 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <span>2. Resultado Vectorial (SVG Puro)</span>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 px-1.5 py-0.2 rounded font-mono">
                Escalable
              </span>
            </span>
            <span className="font-mono text-slate-400 text-[11px] tabular-nums">
              {(new Blob([generatedSvg]).size / 1024).toFixed(1)} KB
            </span>
          </div>
          <div
            className="flex-1 min-h-[300px] bg-white dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-4 overflow-hidden"
            style={{
              backgroundImage: 'radial-gradient(rgba(148, 163, 184, 0.25) 1px, transparent 1px)',
              backgroundSize: '16px 16px',
            }}
          >
            <div
              className="max-w-full max-h-[280px] flex items-center justify-center"
              dangerouslySetInnerHTML={{ __html: generatedSvg }}
            />
          </div>
        </div>

      </div>

      {/* Pro tips banner */}
      <div className="p-4 bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40 rounded-xl text-xs space-y-1 text-slate-600 dark:text-slate-400">
        <strong className="text-slate-900 dark:text-slate-200 block text-xs">
          ¿Necesitas vectorización multicolor o trazado Bézier de ultra-alta fidelidad?
        </strong>
        <p>
          En la pestaña <strong>Directorio</strong> encontrarás herramientas gratuitas especializadas como <strong>SVGcode</strong> (basada en Potrace con WebAssembly) y <strong>VTracer</strong> (con curvas Bézier suaves de visión artificial).
        </p>
      </div>
    </div>
  );
};
