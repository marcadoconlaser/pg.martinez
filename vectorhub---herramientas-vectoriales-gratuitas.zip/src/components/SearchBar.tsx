import React from 'react';
import { Search, X, SlidersHorizontal, Sparkles } from 'lucide-react';

interface SearchBarProps {
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  selectedFormat: string;
  setSelectedFormat: (val: string) => void;
  filterWebOnly: boolean;
  setFilterWebOnly: (val: boolean) => void;
  filterOpenSource: boolean;
  setFilterOpenSource: (val: boolean) => void;
  filterLaserFriendly: boolean;
  setFilterLaserFriendly: (val: boolean) => void;
  filterNoRegistration: boolean;
  setFilterNoRegistration: (val: boolean) => void;
  totalResults: number;
  availableFormats: string[];
  onResetFilters: () => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchQuery,
  setSearchQuery,
  selectedFormat,
  setSelectedFormat,
  filterWebOnly,
  setFilterWebOnly,
  filterOpenSource,
  setFilterOpenSource,
  filterLaserFriendly,
  setFilterLaserFriendly,
  filterNoRegistration,
  setFilterNoRegistration,
  totalResults,
  availableFormats,
  onResetFilters,
}) => {
  const hasActiveFilters =
    Boolean(searchQuery) ||
    selectedFormat !== 'all' ||
    filterWebOnly ||
    filterOpenSource ||
    filterLaserFriendly ||
    filterNoRegistration;

  return (
    <div className="space-y-4">
      {/* Primary search bar */}
      <div className="relative flex items-center">
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
          <Search className="w-5 h-5" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar herramientas por nombre, formato (SVG, DXF), función o corte láser..."
          className="w-full pl-11 pr-24 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 dark:focus:border-indigo-500 shadow-sm text-sm transition-all"
        />
        <div className="absolute inset-y-0 right-0 pr-2.5 flex items-center gap-1.5">
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-md transition-colors"
              title="Borrar búsqueda"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <span className="hidden sm:inline-block text-[11px] font-mono text-slate-400 border border-slate-200 dark:border-slate-700 px-1.5 py-0.5 rounded bg-slate-50 dark:bg-slate-800">
            Esc
          </span>
        </div>
      </div>

      {/* Filter and quick toggle row */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* Quick interactive filter toggles (buttons) */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-slate-400 dark:text-slate-500 flex items-center gap-1 font-medium mr-1">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filtros rápidos:</span>
          </span>

          <button
            onClick={() => setFilterLaserFriendly(!filterLaserFriendly)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ${
              filterLaserFriendly
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-amber-300 dark:hover:border-amber-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Corte Láser & CNC</span>
          </button>

          <button
            onClick={() => setFilterWebOnly(!filterWebOnly)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              filterWebOnly
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-indigo-300 dark:hover:border-indigo-700'
            }`}
          >
            Solo en Navegador (Web)
          </button>

          <button
            onClick={() => setFilterOpenSource(!filterOpenSource)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              filterOpenSource
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-emerald-300 dark:hover:border-emerald-700'
            }`}
          >
            Código Abierto (Open Source)
          </button>

          <button
            onClick={() => setFilterNoRegistration(!filterNoRegistration)}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              filterNoRegistration
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-cyan-300 dark:hover:border-cyan-700'
            }`}
          >
            Sin Registro Requerido
          </button>

          {/* Format selector */}
          <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-2.5 py-1">
            <span className="text-slate-400 font-medium">Formato:</span>
            <select
              value={selectedFormat}
              onChange={(e) => setSelectedFormat(e.target.value)}
              className="bg-transparent text-slate-700 dark:text-slate-200 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="all" className="dark:bg-slate-900">Todos</option>
              {availableFormats.map((fmt) => (
                <option key={fmt} value={fmt} className="dark:bg-slate-900">
                  {fmt}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Counter & reset */}
        <div className="flex items-center gap-3 ml-auto text-slate-500 dark:text-slate-400">
          <span className="font-mono tabular-nums text-xs">
            <strong className="text-slate-900 dark:text-white font-semibold">{totalResults}</strong> {totalResults === 1 ? 'herramienta encontrada' : 'herramientas encontradas'}
          </span>
          {hasActiveFilters && (
            <button
              onClick={onResetFilters}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-medium"
            >
              Restablecer filtros
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
