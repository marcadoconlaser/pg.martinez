import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Copy,
  Download,
  Eye,
  Check,
  ZoomIn,
  ZoomOut,
  Maximize2,
  FileCode,
  Flame,
  AlertTriangle,
  RefreshCw,
} from 'lucide-react';

// Sample vectors to test right away
const SAMPLES = {
  laser_box: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 150" width="200mm" height="150mm">
  <!-- Cara frontal con ensamble de dedos -->
  <path d="M 20 20 h 20 v 10 h 20 v -10 h 20 v 10 h 20 v -10 h 20 v 30 h -10 v 20 h 10 v 20 h -10 v 20 h 10 v 20 h -20 v -10 h -20 v 10 h -20 v -10 h -20 v 10 h -20 v -30 h 10 v -20 h -10 v -20 h 10 v -20 h -10 Z" fill="none" stroke="#DC2626" stroke-width="0.5" />
  <!-- Orificio central decorativo -->
  <circle cx="80" cy="75" r="18" fill="none" stroke="#DC2626" stroke-width="0.5" />
  <!-- Marcado interior de referencia -->
  <line x1="45" y1="75" x2="115" y2="75" stroke="#2563EB" stroke-width="0.3" stroke-dasharray="2,2" />
  <line x1="80" y1="40" x2="80" y2="110" stroke="#2563EB" stroke-width="0.3" stroke-dasharray="2,2" />
</svg>`,
  mandala: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-100 -100 200 200" width="200" height="200">
  <g fill="none" stroke="#10B981" stroke-width="0.8">
    <circle cx="0" cy="0" r="90" />
    <circle cx="0" cy="0" r="60" />
    <circle cx="0" cy="0" r="30" />
    <path d="M 0 -90 Q 30 -60 0 -30 Q -30 -60 0 -90 Z" />
    <path d="M 0 90 Q 30 60 0 30 Q -30 60 0 90 Z" />
    <path d="M -90 0 Q -60 30 -30 0 Q -60 -30 -90 0 Z" />
    <path d="M 90 0 Q 60 30 30 0 Q 60 -30 90 0 Z" />
    <path d="M -63.6 -63.6 Q -21.2 -42.4 0 0 Q -42.4 -21.2 -63.6 -63.6 Z" />
    <path d="M 63.6 63.6 Q 21.2 42.4 0 0 Q 42.4 21.2 63.6 63.6 Z" />
    <path d="M -63.6 63.6 Q -42.4 21.2 0 0 Q -21.2 42.4 -63.6 63.6 Z" />
    <path d="M 63.6 -63.6 Q 42.4 -21.2 0 0 Q 21.2 -42.4 63.6 -63.6 Z" />
  </g>
</svg>`,
  gear: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160" width="160" height="160">
  <path d="M 80 15 L 86 15 L 88 28 L 98 32 L 108 23 L 114 27 L 110 39 L 119 46 L 131 42 L 134 48 L 126 58 L 131 68 L 144 69 L 144 76 L 131 80 L 128 90 L 138 99 L 133 105 L 121 102 L 113 110 L 116 123 L 109 126 L 101 118 L 91 123 L 90 136 L 83 136 L 80 123 L 70 120 L 61 129 L 55 125 L 59 112 L 50 106 L 37 110 L 34 104 L 43 94 L 38 84 L 25 83 L 25 76 L 38 72 L 41 62 L 31 53 L 36 47 L 48 50 L 56 42 L 53 29 L 60 26 L 68 34 L 78 29 Z M 80 50 A 30 30 0 1 0 80 110 A 30 30 0 1 0 80 50 Z" fill="#4F46E5" fill-rule="evenodd" stroke="#312E81" stroke-width="1" />
  <circle cx="80" cy="80" r="10" fill="#FFFFFF" stroke="#312E81" stroke-width="1" />
</svg>`
};

export const SvgInspector: React.FC = () => {
  const [svgCode, setSvgCode] = useState<string>(SAMPLES.laser_box);
  const [zoom, setZoom] = useState<number>(1);
  const [wireframeMode, setWireframeMode] = useState<boolean>(false);
  const [bgStyle, setBgStyle] = useState<'grid' | 'dark' | 'light' | 'checkers'>('grid');
  const [copied, setCopied] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Analysis state
  const [stats, setStats] = useState({
    width: '',
    height: '',
    viewBox: '',
    paths: 0,
    circles: 0,
    rects: 0,
    lines: 0,
    polygons: 0,
    texts: 0,
    bytes: 0,
    hasTexts: false,
    hasMissingViewBox: false,
    estimatedNodes: 0,
  });

  useEffect(() => {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(svgCode, 'image/svg+xml');
      const svgEl = doc.querySelector('svg');

      if (svgEl) {
        const width = svgEl.getAttribute('width') || '100%';
        const height = svgEl.getAttribute('height') || '100%';
        const viewBox = svgEl.getAttribute('viewBox') || 'No definido';
        const paths = doc.querySelectorAll('path').length;
        const circles = doc.querySelectorAll('circle').length;
        const rects = doc.querySelectorAll('rect').length;
        const lines = doc.querySelectorAll('line').length;
        const polygons = doc.querySelectorAll('polygon, polyline').length;
        const texts = doc.querySelectorAll('text, tspan').length;

        // Count approximate nodes from d attributes
        let nodeCount = 0;
        doc.querySelectorAll('path').forEach((p) => {
          const d = p.getAttribute('d') || '';
          nodeCount += (d.match(/[MLHVCSQTAZmlhvcsqtaz]/g) || []).length;
        });

        setStats({
          width,
          height,
          viewBox,
          paths,
          circles,
          rects,
          lines,
          polygons,
          texts,
          bytes: new Blob([svgCode]).size,
          hasTexts: texts > 0,
          hasMissingViewBox: viewBox === 'No definido',
          estimatedNodes: nodeCount || paths * 4,
        });
      }
    } catch {
      // Ignore parse errors while typing
    }
  }, [svgCode]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) setSvgCode(content);
      };
      reader.readAsText(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && (file.type === 'image/svg+xml' || file.name.endsWith('.svg'))) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) setSvgCode(content);
      };
      reader.readAsText(file);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(svgCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([svgCode], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vector_${Date.now()}.svg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Title & info banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FileCode className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Inspector y Visor de Vectores SVG</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Arrastra tu archivo SVG o pega su código para auditar dimensiones, trazados de corte láser, nodos y peso.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".svg,image/svg+xml"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Upload className="w-4 h-4 text-indigo-500" />
            <span>Subir SVG</span>
          </button>

          <button
            onClick={handleCopy}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/60 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copiado' : 'Copiar'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Descargar</span>
          </button>
        </div>
      </div>

      {/* Main Split View: Viewport on Left, Code & Analysis on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Interactive Visual Canvas (7 cols) */}
        <div className="lg:col-span-7 flex flex-col space-y-3">
          
          {/* Canvas Controls Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs">
            
            {/* Background Style Switcher */}
            <div className="flex items-center gap-1">
              <span className="text-slate-400 font-medium px-2">Fondo:</span>
              <button
                onClick={() => setBgStyle('grid')}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                  bgStyle === 'grid'
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                Malla mm
              </button>
              <button
                onClick={() => setBgStyle('light')}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                  bgStyle === 'light'
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                Blanco
              </button>
              <button
                onClick={() => setBgStyle('dark')}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                  bgStyle === 'dark'
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                Oscuro
              </button>
            </div>

            {/* Wireframe & Zoom */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setWireframeMode(!wireframeMode)}
                className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors flex items-center gap-1 ${
                  wireframeMode
                    ? 'bg-amber-500 text-white font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                title="Muestra solo los trazos de corte (stroke) eliminando los rellenos"
              >
                <Flame className="w-3.5 h-3.5" />
                <span>Vista Corte (Wireframe)</span>
              </button>

              <div className="flex items-center gap-1 border-l border-slate-200 dark:border-slate-800 pl-2">
                <button
                  onClick={() => setZoom((z) => Math.max(0.25, z - 0.25))}
                  className="p-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                  title="Alejar"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>
                <span className="font-mono text-[11px] w-12 text-center tabular-nums">
                  {Math.round(zoom * 100)}%
                </span>
                <button
                  onClick={() => setZoom((z) => Math.min(4, z + 0.25))}
                  className="p-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                  title="Acercar"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setZoom(1)}
                  className="p-1 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                  title="Restablecer 100%"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>

          {/* Interactive Canvas Viewport */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            className={`relative w-full h-[460px] rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex items-center justify-center transition-colors select-none ${
              bgStyle === 'dark'
                ? 'bg-slate-950'
                : bgStyle === 'light'
                ? 'bg-white'
                : 'bg-slate-50 dark:bg-slate-900'
            }`}
            style={{
              backgroundImage:
                bgStyle === 'grid'
                  ? 'radial-gradient(rgba(148, 163, 184, 0.3) 1px, transparent 1px)'
                  : undefined,
              backgroundSize: bgStyle === 'grid' ? '20px 20px' : undefined,
            }}
          >
            {/* Transformed SVG Container */}
            <div
              className={`transition-transform duration-100 p-8 flex items-center justify-center max-w-full max-h-full ${
                wireframeMode ? '[&_*]:!fill-none [&_*]:!stroke-amber-500 [&_*]:!stroke-[0.75px]' : ''
              }`}
              style={{ transform: `scale(${zoom})` }}
              dangerouslySetInnerHTML={{ __html: svgCode }}
            />

            {/* Drop overlay badge */}
            <div className="absolute bottom-3 left-3 text-[11px] text-slate-400 bg-white/80 dark:bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-md border border-slate-200 dark:border-slate-800 pointer-events-none">
              Arrastra un archivo .svg aquí
            </div>
          </div>

          {/* Sample quick switcher */}
          <div className="flex items-center gap-2 text-xs pt-1">
            <span className="text-slate-400 font-medium">Ejemplos listos:</span>
            <button
              onClick={() => setSvgCode(SAMPLES.laser_box)}
              className="px-2.5 py-1 text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md hover:border-indigo-400 text-[11px]"
            >
              Caja con Ensamble (Láser)
            </button>
            <button
              onClick={() => setSvgCode(SAMPLES.mandala)}
              className="px-2.5 py-1 text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md hover:border-indigo-400 text-[11px]"
            >
              Mandala Ornamental
            </button>
            <button
              onClick={() => setSvgCode(SAMPLES.gear)}
              className="px-2.5 py-1 text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md hover:border-indigo-400 text-[11px]"
            >
              Engranaje Mecánico
            </button>
          </div>
        </div>

        {/* Right Column: Code Editor & Analysis (5 cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-4">
          
          {/* Audit Metrics Panel */}
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center justify-between">
              <span>Auditoría de Geometría</span>
              <span className="font-mono text-indigo-600 dark:text-indigo-400 tabular-nums">
                {(stats.bytes / 1024).toFixed(1)} KB
              </span>
            </h4>

            {/* Dimension Specs */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Dimensiones:</span>
                <span className="font-mono font-medium text-slate-800 dark:text-slate-200">
                  {stats.width} × {stats.height}
                </span>
              </div>
              <div className="p-2 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-[11px] text-slate-400 block">ViewBox:</span>
                <span className="font-mono font-medium text-slate-800 dark:text-slate-200 truncate block">
                  {stats.viewBox}
                </span>
              </div>
            </div>

            {/* Elements Breakup */}
            <div className="grid grid-cols-4 gap-1.5 text-center text-xs">
              <div className="p-2 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-[10px] text-slate-400 block">Trayectos</span>
                <strong className="font-mono text-sm text-slate-900 dark:text-white tabular-nums">
                  {stats.paths}
                </strong>
              </div>
              <div className="p-2 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-[10px] text-slate-400 block">Círculos</span>
                <strong className="font-mono text-sm text-slate-900 dark:text-white tabular-nums">
                  {stats.circles}
                </strong>
              </div>
              <div className="p-2 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-[10px] text-slate-400 block">Rectángulos</span>
                <strong className="font-mono text-sm text-slate-900 dark:text-white tabular-nums">
                  {stats.rects}
                </strong>
              </div>
              <div className="p-2 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-[10px] text-slate-400 block">Nodos Aprox.</span>
                <strong className="font-mono text-sm text-indigo-600 dark:text-indigo-400 tabular-nums">
                  {stats.estimatedNodes}
                </strong>
              </div>
            </div>

            {/* Laser Warnings & Checks */}
            {stats.hasTexts && (
              <div className="p-2.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 rounded-lg flex items-start gap-2 text-xs text-amber-800 dark:text-amber-300">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                <div>
                  <strong>¡Atención!:</strong> Contiene etiquetas &lt;text&gt; editables. Si vas a cortar en láser, conviértelas a curvas en Inkscape para que la máquina no pierda la tipografía.
                </div>
              </div>
            )}

            {stats.hasMissingViewBox && (
              <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-lg flex items-start gap-2 text-xs text-rose-800 dark:text-rose-300">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                <div>
                  No se detectó atributo <code>viewBox</code>. Algunos programas de corte pueden desescalar el vector.
                </div>
              </div>
            )}
          </div>

          {/* Raw SVG Code Editor */}
          <div className="flex-1 flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden min-h-[220px]">
            <div className="px-4 py-2 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                Código fuente SVG (Editable)
              </span>
              <button
                onClick={() => setSvgCode(SAMPLES.laser_box)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 flex items-center gap-1"
                title="Restablecer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Reiniciar</span>
              </button>
            </div>
            <textarea
              value={svgCode}
              onChange={(e) => setSvgCode(e.target.value)}
              spellCheck={false}
              className="w-full flex-1 p-3 text-[11px] font-mono leading-relaxed bg-transparent text-slate-800 dark:text-slate-200 focus:outline-none resize-none overflow-y-auto"
            />
          </div>

        </div>

      </div>
    </div>
  );
};
