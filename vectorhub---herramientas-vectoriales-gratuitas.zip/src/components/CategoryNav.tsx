import React from 'react';
import { ToolCategory, CategoryInfo } from '../types/vector';
import {
  Layers,
  PenTool,
  Wand2,
  Cpu,
  Minimize2,
  FolderOpen,
  ArrowLeftRight,
} from 'lucide-react';

interface CategoryNavProps {
  categories: CategoryInfo[];
  selectedCategory: ToolCategory;
  onSelectCategory: (cat: ToolCategory) => void;
  categoryCounts: Record<ToolCategory, number>;
}

const CATEGORY_ICONS: Record<ToolCategory, React.ReactNode> = {
  all: <Layers className="w-4 h-4" />,
  editors: <PenTool className="w-4 h-4" />,
  vectorizers: <Wand2 className="w-4 h-4" />,
  laser_cnc: <Cpu className="w-4 h-4" />,
  optimizers: <Minimize2 className="w-4 h-4" />,
  repositories: <FolderOpen className="w-4 h-4" />,
  converters: <ArrowLeftRight className="w-4 h-4" />,
};

export const CategoryNav: React.FC<CategoryNavProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  categoryCounts,
}) => {
  return (
    <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          const count = categoryCounts[cat.id] ?? 0;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${
                isSelected
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
              }`}
            >
              <span className={isSelected ? 'text-indigo-400 dark:text-indigo-600' : 'text-slate-400 dark:text-slate-500'}>
                {CATEGORY_ICONS[cat.id]}
              </span>
              <span>{cat.label}</span>
              <span
                className={`text-[11px] font-mono px-1.5 py-0.2 rounded font-normal tabular-nums ${
                  isSelected
                    ? 'bg-slate-800 text-slate-300 dark:bg-slate-200 dark:text-slate-700'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
