import React, { useState } from 'react';
import { VectorTool, ToolCategory, PlatformType, LicenseType } from '../types/vector';
import { X, Plus, AlertCircle } from 'lucide-react';

interface AddToolModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddTool: (tool: VectorTool) => void;
}

export const AddToolModal: React.FC<AddToolModalProps> = ({
  isOpen,
  onClose,
  onAddTool,
}) => {
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [category, setCategory] = useState<ToolCategory>('editors');
  const [shortDescription, setShortDescription] = useState('');
  const [bestFor, setBestFor] = useState('');
  const [formatsInput, setFormatsInput] = useState('SVG, DXF');
  const [platform, setPlatform] = useState<PlatformType>('Web (En navegador)');
  const [license, setLicense] = useState<LicenseType>('Gratis sin registro');
  const [laserFriendly, setLaserFriendly] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !url.trim() || !shortDescription.trim()) {
      setError('Por favor completa al menos el nombre, enlace web y breve descripción.');
      return;
    }

    let formattedUrl = url.trim();
    if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
      formattedUrl = 'https://' + formattedUrl;
    }

    const formats = formatsInput
      .split(',')
      .map((f) => f.trim().toUpperCase())
      .filter(Boolean);

    const newTool: VectorTool = {
      id: `custom_${Date.now()}`,
      name: name.trim(),
      url: formattedUrl,
      category,
      shortDescription: shortDescription.trim(),
      detailedDescription: shortDescription.trim(),
      bestFor: bestFor.trim() || 'Uso general en proyectos vectoriales.',
      formats: formats.length > 0 ? formats : ['SVG'],
      platform,
      license,
      requiresRegistration: license.includes('con registro'),
      laserFriendly,
      tags: ['Personalizada', ...formats],
      tips: ['Herramienta guardada por el usuario en su navegador.'],
      isCustom: true,
    };

    onAddTool(newTool);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Plus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Agregar Herramienta Vectorial
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Se guardará en tu navegador para que siempre la tengas a mano
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto text-xs">
          {error && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 rounded-lg text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Nombre de la herramienta *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ej. SVGOMG, MakerCase, Boxy SVG..."
              className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              URL / Enlace oficial *
            </label>
            <input
              type="text"
              required
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://ejemplo.com"
              className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Categoría
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as ToolCategory)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="editors">Editores Vectoriales</option>
                <option value="vectorizers">Vectorizadores (Raster a Vector)</option>
                <option value="laser_cnc">Corte Láser & CNC</option>
                <option value="optimizers">Optimizadores SVG</option>
                <option value="repositories">Bancos de Vectores</option>
                <option value="converters">Conversores</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Plataforma
              </label>
              <select
                value={platform}
                onChange={(e) => setPlatform(e.target.value as PlatformType)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Web (En navegador)">Web (En navegador)</option>
                <option value="Windows / Mac / Linux">Windows / Mac / Linux</option>
                <option value="Web y Software">Web y Software</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Breve descripción (¿Qué hace?) *
            </label>
            <textarea
              required
              rows={2}
              value={shortDescription}
              onChange={(e) => setShortDescription(e.target.value)}
              placeholder="Ej. Herramienta ligera para recortar trazados y exportar en DXF."
              className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              ¿Ideal para qué caso? (Opcional)
            </label>
            <input
              type="text"
              value={bestFor}
              onChange={(e) => setBestFor(e.target.value)}
              placeholder="Ej. Generar cajas de madera con ensamble a presión."
              className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Formatos (separados por coma)
              </label>
              <input
                type="text"
                value={formatsInput}
                onChange={(e) => setFormatsInput(e.target.value)}
                placeholder="SVG, DXF, EPS"
                className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Licencia
              </label>
              <select
                value={license}
                onChange={(e) => setLicense(e.target.value as LicenseType)}
                className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Gratis sin registro">Gratis sin registro</option>
                <option value="Código Abierto (Open Source)">Código Abierto (Open Source)</option>
                <option value="Plan Gratuito Generoso">Plan Gratuito Generoso</option>
                <option value="Gratis con registro">Gratis con registro</option>
              </select>
            </div>
          </div>

          <div className="pt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={laserFriendly}
                onChange={(e) => setLaserFriendly(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
              />
              <span className="font-medium text-slate-700 dark:text-slate-300">
                Es especialmente útil para Corte Láser, Grabado o CNC (DXF/SVG limpio)
              </span>
            </label>
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors"
            >
              Guardar herramienta
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
