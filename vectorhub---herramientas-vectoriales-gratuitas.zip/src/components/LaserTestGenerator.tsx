import React, { useState, useMemo } from 'react';
import {
  Flame,
  Download,
  Copy,
  Check,
  ArrowRight,
  Settings2,
  Layers,
} from 'lucide-react';

interface LaserTestGeneratorProps {
  onSendToInspector: (svgString: string) => void;
}

export const LaserTestGenerator: React.FC<LaserTestGeneratorProps> = ({
  onSendToInspector,
}) => {
  const [materialLabel, setMaterialLabel] = useState<string>('MDF 3mm - Lente Estándar');
  const [rowsCount, setRowsCount] = useState<number>(5); // Speeds
  const [colsCount, setColsCount] = useState<number>(5); // Powers
  const [minSpeed, setMinSpeed] = useState<number>(100);
  const [maxSpeed, setMaxSpeed] = useState<number>(500);
  const [minPower, setMinPower] = useState<number>(10);
  const [maxPower, setMaxPower] = useState<number>(90);
  const [cellSize, setCellSize] = useState<number>(8); // mm
  const [cellGap, setCellGap] = useState<number>(2); // mm
  const [testType, setTestType] = useState<'engrave' | 'cut'>('engrave');
  const [copied, setCopied] = useState<boolean>(false);

  // Generate SVG matrix
  const svgOutput = useMemo(() => {
    const margin = 20; // mm
    const headerHeight = 15; // mm
    const labelWidth = 18; // mm for speed labels on left
    const labelHeight = 8; // mm for power labels on top

    const gridW = colsCount * cellSize + (colsCount - 1) * cellGap;
    const gridH = rowsCount * cellSize + (rowsCount - 1) * cellGap;

    const totalW = Math.round(margin * 2 + labelWidth + gridW);
    const totalH = Math.round(margin * 2 + headerHeight + labelHeight + gridH);

    // Calculate step values
    const speeds: number[] = [];
    const speedStep = rowsCount > 1 ? (maxSpeed - minSpeed) / (rowsCount - 1) : 0;
    for (let i = 0; i < rowsCount; i++) {
      speeds.push(Math.round(minSpeed + i * speedStep));
    }

    const powers: number[] = [];
    const powerStep = colsCount > 1 ? (maxPower - minPower) / (colsCount - 1) : 0;
    for (let j = 0; j < colsCount; j++) {
      powers.push(Math.round(minPower + j * powerStep));
    }

    // Header & Frame
    let elements = `
  <!-- Marco exterior y título del material -->
  <rect x="5" y="5" width="${totalW - 10}" height="${totalH - 10}" fill="none" stroke="#64748B" stroke-width="0.3" rx="3" />
  <text x="${totalW / 2}" y="14" font-family="sans-serif" font-size="3.5" font-weight="bold" fill="#0F172A" text-anchor="middle">
    TEST DE CALIBRACIÓN LÁSER: ${materialLabel}
  </text>
  <text x="${totalW / 2}" y="18.5" font-family="sans-serif" font-size="2" fill="#64748B" text-anchor="middle">
    Generado en VectorHub · Potencia (%) vs Velocidad (mm/s)
  </text>
`;

    const startX = margin + labelWidth;
    const startY = margin + headerHeight + labelHeight;

    // Power column labels (top)
    powers.forEach((pwr, colIdx) => {
      const x = startX + colIdx * (cellSize + cellGap) + cellSize / 2;
      elements += `
  <text x="${x}" y="${startY - 2.5}" font-family="sans-serif" font-size="2.2" font-weight="bold" fill="#0F172A" text-anchor="middle">
    ${pwr}%
  </text>`;
    });

    // Speed row labels (left) and test patches
    speeds.forEach((spd, rowIdx) => {
      const y = startY + rowIdx * (cellSize + cellGap);
      
      // Speed text on left
      elements += `
  <text x="${startX - 2}" y="${y + cellSize / 2 + 0.8}" font-family="sans-serif" font-size="2.2" font-weight="bold" fill="#0F172A" text-anchor="end">
    ${spd}
  </text>`;

      // Cells
      powers.forEach((pwr, colIdx) => {
        const x = startX + colIdx * (cellSize + cellGap);
        
        if (testType === 'engrave') {
          // Shading simulator based on power/speed ratio
          const intensity = Math.min(0.95, Math.max(0.1, (pwr / 100) * (minSpeed / spd)));
          const hexVal = Math.round(255 * (1 - intensity)).toString(16).padStart(2, '0');
          const color = `#${hexVal}${hexVal}${hexVal}`;

          elements += `
  <rect x="${x}" y="${y}" width="${cellSize}" height="${cellSize}" fill="${color}" stroke="#0F172A" stroke-width="0.1" data-speed="${spd}" data-power="${pwr}" />`;
        } else {
          // Cut lines test
          elements += `
  <rect x="${x}" y="${y}" width="${cellSize}" height="${cellSize}" fill="none" stroke="#DC2626" stroke-width="0.25" data-speed="${spd}" data-power="${pwr}" />`;
        }
      });
    });

    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${totalW} ${totalH}" width="${totalW}mm" height="${totalH}mm">
${elements}
</svg>`;
  }, [materialLabel, rowsCount, colsCount, minSpeed, maxSpeed, minPower, maxPower, cellSize, cellGap, testType]);

  const handleCopy = () => {
    navigator.clipboard.writeText(svgOutput);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([svgOutput], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `laser_test_matrix_${Date.now()}.svg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-500" />
            <span>Generador de Matriz de Prueba para Corte y Grabado Láser</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Crea en segundos un archivo SVG milimétrico con parches de calibración (Potencia vs Velocidad) listo para LightBurn, LaserGRBL o RDWorks.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copiado' : 'Copiar SVG'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Descargar SVG (mm)</span>
          </button>
        </div>
      </div>

      {/* Grid: Parameters on left, Live Preview on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Configuration Form (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            <Settings2 className="w-4 h-4 text-indigo-500" />
            <span>Parámetros de Calibración</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Nombre de prueba / Material
            </label>
            <input
              type="text"
              value={materialLabel}
              onChange={(e) => setMaterialLabel(e.target.value)}
              placeholder="Ej. MDF 3mm, Acrílico Negro 2mm, Cuero"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Test Type: Grabado vs Corte */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
              Tipo de matriz
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setTestType('engrave')}
                className={`py-2 px-3 rounded-lg font-medium border text-center transition-all ${
                  testType === 'engrave'
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-transparent shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
              >
                Grabado (Relleno)
              </button>
              <button
                type="button"
                onClick={() => setTestType('cut')}
                className={`py-2 px-3 rounded-lg font-medium border text-center transition-all flex items-center justify-center gap-1.5 ${
                  testType === 'cut'
                    ? 'bg-amber-600 text-white border-transparent shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>Corte (Líneas)</span>
              </button>
            </div>
          </div>

          {/* Speeds */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-2 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300 block">
              Velocidad (Eje Vertical, mm/s)
            </span>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <span className="text-[10px] text-slate-400 block mb-0.5">Mínima:</span>
                <input
                  type="number"
                  min="10"
                  max="1000"
                  step="10"
                  value={minSpeed}
                  onChange={(e) => setMinSpeed(Number(e.target.value))}
                  className="w-full px-2 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-xs font-mono"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block mb-0.5">Máxima:</span>
                <input
                  type="number"
                  min="20"
                  max="2000"
                  step="20"
                  value={maxSpeed}
                  onChange={(e) => setMaxSpeed(Number(e.target.value))}
                  className="w-full px-2 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-xs font-mono"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block mb-0.5">Filas:</span>
                <input
                  type="number"
                  min="2"
                  max="10"
                  value={rowsCount}
                  onChange={(e) => setRowsCount(Number(e.target.value))}
                  className="w-full px-2 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-xs font-mono"
                />
              </div>
            </div>
          </div>

          {/* Powers */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-2 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300 block">
              Potencia (Eje Horizontal, %)
            </span>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <span className="text-[10px] text-slate-400 block mb-0.5">Mínima (%):</span>
                <input
                  type="number"
                  min="5"
                  max="95"
                  step="5"
                  value={minPower}
                  onChange={(e) => setMinPower(Number(e.target.value))}
                  className="w-full px-2 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-xs font-mono"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block mb-0.5">Máxima (%):</span>
                <input
                  type="number"
                  min="10"
                  max="100"
                  step="5"
                  value={maxPower}
                  onChange={(e) => setMaxPower(Number(e.target.value))}
                  className="w-full px-2 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-xs font-mono"
                />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block mb-0.5">Columnas:</span>
                <input
                  type="number"
                  min="2"
                  max="10"
                  value={colsCount}
                  onChange={(e) => setColsCount(Number(e.target.value))}
                  className="w-full px-2 py-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-xs font-mono"
                />
              </div>
            </div>
          </div>

          {/* Size & Gap */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1">
                Tamaño del parche (mm):
              </label>
              <input
                type="number"
                min="4"
                max="25"
                value={cellSize}
                onChange={(e) => setCellSize(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1">
                Espacio entre parches (mm):
              </label>
              <input
                type="number"
                min="1"
                max="10"
                value={cellGap}
                onChange={(e) => setCellGap(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => onSendToInspector(svgOutput)}
              className="w-full py-2.5 px-3 text-xs font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 rounded-xl border border-indigo-200 dark:border-indigo-900/60 flex items-center justify-center gap-2 transition-colors"
            >
              <span>Abrir esta matriz en Inspector SVG</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>

        {/* Right: Live Millimeter SVG Preview (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-3 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-indigo-500" />
              <span>Vista previa vectorial (Escala real en mm)</span>
            </span>
            <span className="font-mono text-slate-400 text-[11px] tabular-nums">
              Total parches: {rowsCount * colsCount}
            </span>
          </div>

          <div
            className="flex-1 min-h-[420px] bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center p-6 overflow-auto"
            style={{
              backgroundImage: 'radial-gradient(rgba(148, 163, 184, 0.3) 1px, transparent 1px)',
              backgroundSize: '15px 15px',
            }}
          >
            <div
              className="max-w-full max-h-full drop-shadow-sm bg-white p-3 rounded"
              dangerouslySetInnerHTML={{ __html: svgOutput }}
            />
          </div>

          <div className="pt-3 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>Compatible con LightBurn, LaserGRBL, Inkscape y RDWorks</span>
            <span className="font-mono">Unidades: mm</span>
          </div>
        </div>

      </div>
    </div>
  );
};
