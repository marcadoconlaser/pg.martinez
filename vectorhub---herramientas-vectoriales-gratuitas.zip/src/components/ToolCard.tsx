import React, { useState } from 'react';
import { VectorTool } from '../types/vector';
import {
  ExternalLink,
  Bookmark,
  Info,
  Check,
  Copy,
  Flame,
  Globe,
  Monitor,
} from 'lucide-react';

interface ToolCardProps {
  tool: VectorTool;
  isFavorite: boolean;
  onToggleFavorite: (toolId: string) => void;
  onOpenDetails: (tool: VectorTool) => void;
}

export const ToolCard: React.FC<ToolCardProps> = ({
  tool,
  isFavorite,
  onToggleFavorite,
  onOpenDetails,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(tool.url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <article className="group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-md transition-all flex flex-col justify-between">
      <div>
        {/* Top metadata line: Unboxed clean text with typographic separators (Zero-Pill discipline) */}
        <div className="flex items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400 mb-2.5">
          <div className="flex items-center gap-1.5 truncate">
            {tool.platform.includes('Web') ? (
              <Globe className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            ) : (
              <Monitor className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            )}
            <span className="truncate">{tool.platform}</span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{tool.license}</span>
          </div>

          {/* Laser tag if applicable: quiet inline highlight */}
          {tool.laserFriendly && (
            <span className="flex items-center gap-1 text-[11px] font-medium text-amber-600 dark:text-amber-400 shrink-0">
              <Flame className="w-3 h-3 text-amber-500" />
              <span>Láser / CNC</span>
            </span>
          )}
        </div>

        {/* Title & Bookmark header */}
        <div className="flex items-start justify-between gap-3 mb-2">
          <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
            {tool.name}
          </h3>
          <button
            onClick={() => onToggleFavorite(tool.id)}
            aria-label={isFavorite ? 'Quitar de favoritos' : 'Guardar en favoritos'}
            className="text-slate-400 hover:text-amber-500 dark:hover:text-amber-400 p-1 -mr-1 rounded-md transition-colors"
          >
            <Bookmark className={`w-4 h-4 ${isFavorite ? 'fill-amber-500 text-amber-500' : ''}`} />
          </button>
        </div>

        {/* Short description */}
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-3 line-clamp-2">
          {tool.shortDescription}
        </p>

        {/* Best for highlight */}
        <div className="text-xs text-slate-500 dark:text-slate-400 mb-4 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800/80">
          <strong className="text-slate-700 dark:text-slate-300 font-semibold block text-[11px] uppercase tracking-wider mb-0.5">
            Ideal para:
          </strong>
          <span className="line-clamp-2 text-slate-600 dark:text-slate-300 text-xs">
            {tool.bestFor}
          </span>
        </div>
      </div>

      {/* Card bottom footer */}
      <div>
        {/* Formats line (clean unboxed text) */}
        <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mb-4 pt-1">
          <span className="font-semibold text-slate-700 dark:text-slate-300">Formatos:</span>
          <div className="flex items-center gap-1 font-mono text-[11px] flex-wrap">
            {tool.formats.map((fmt, idx) => (
              <React.Fragment key={fmt}>
                <span className="text-slate-600 dark:text-slate-300">{fmt}</span>
                {idx < tool.formats.length - 1 && <span className="text-slate-300 dark:text-slate-600">/</span>}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-1">
            <button
              onClick={() => onOpenDetails(tool)}
              className="px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors flex items-center gap-1"
              title="Ver detalles, formatos y trucos de uso"
            >
              <Info className="w-3.5 h-3.5" />
              <span>Detalles</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
              title="Copiar enlace oficial"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <a
            href={tool.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-100 dark:text-slate-900 hover:bg-indigo-600 dark:hover:bg-indigo-500 dark:hover:text-white rounded-lg transition-colors whitespace-nowrap shadow-sm"
          >
            <span>Ir al sitio</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </article>
  );
};
