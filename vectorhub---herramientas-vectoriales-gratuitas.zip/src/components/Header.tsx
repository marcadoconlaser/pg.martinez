import React from 'react';
import { Bookmark, Moon, Sun, Plus } from 'lucide-react';

interface HeaderProps {
  activeTab: 'directory' | 'inspector' | 'vectorizer' | 'laser_matrix';
  setActiveTab: (tab: 'directory' | 'inspector' | 'vectorizer' | 'laser_matrix') => void;
  favoritesCount: number;
  showFavoritesOnly: boolean;
  setShowFavoritesOnly: (val: boolean) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  onOpenAddModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  favoritesCount,
  showFavoritesOnly,
  setShowFavoritesOnly,
  isDarkMode,
  toggleDarkMode,
  onOpenAddModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200 dark:bg-slate-900/90 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        
        {/* Zone 1: Brand wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => {
              setActiveTab('directory');
              setShowFavoritesOnly(false);
            }}
            className="flex items-center gap-2.5 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded"
          >
            <div className="w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-lg shadow-sm shadow-indigo-500/20 group-hover:bg-indigo-700 transition-colors">
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 2L2 7l10 5 10-5-10-5z" />
                <path d="M2 17l10 5 10-5" />
                <path d="M2 12l10 5 10-5" />
              </svg>
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
                VectorHub
              </span>
              <span className="hidden sm:inline-block text-[11px] font-medium text-slate-500 dark:text-slate-400 ml-2 tracking-wide uppercase">
                Herramientas Gratuitas
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (single line, whitespace-nowrap) */}
        <nav className="hidden md:flex items-center gap-1 text-sm font-medium">
          <button
            onClick={() => {
              setActiveTab('directory');
              setShowFavoritesOnly(false);
            }}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'directory' && !showFavoritesOnly
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold bg-indigo-50 dark:bg-indigo-950/60'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Directorio
          </button>

          <button
            onClick={() => setActiveTab('inspector')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'inspector'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold bg-indigo-50 dark:bg-indigo-950/60'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Inspector SVG
          </button>

          <button
            onClick={() => setActiveTab('vectorizer')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'vectorizer'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold bg-indigo-50 dark:bg-indigo-950/60'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Vectorizador Express
          </button>

          <button
            onClick={() => setActiveTab('laser_matrix')}
            className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'laser_matrix'
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold bg-indigo-50 dark:bg-indigo-950/60'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Matriz de Prueba Láser
          </button>

          <button
            onClick={() => {
              setActiveTab('directory');
              setShowFavoritesOnly(!showFavoritesOnly);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap shrink-0 ${
              showFavoritesOnly
                ? 'text-amber-600 dark:text-amber-400 font-semibold bg-amber-50 dark:bg-amber-950/50'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Ver herramientas guardadas en favoritos"
          >
            <Bookmark className={`w-4 h-4 ${showFavoritesOnly ? 'fill-amber-500 text-amber-500' : ''}`} />
            <span>Favoritos</span>
            {favoritesCount > 0 && (
              <span className="text-xs font-mono font-medium px-1.5 py-0.2 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 tabular-nums">
                {favoritesCount}
              </span>
            )}
          </button>
        </nav>

        {/* Zone 3: Primary Action + Dark mode */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={toggleDarkMode}
            aria-label={isDarkMode ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro'}
            className="p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-indigo-500"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Agregar Enlace</span>
          </button>
        </div>

      </div>

      {/* Mobile navigation bar */}
      <div className="md:hidden flex items-center justify-around px-2 py-2 border-t border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-900/90 text-xs overflow-x-auto">
        <button
          onClick={() => {
            setActiveTab('directory');
            setShowFavoritesOnly(false);
          }}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'directory' && !showFavoritesOnly
              ? 'font-semibold text-indigo-600 dark:text-indigo-400'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Directorio
        </button>
        <button
          onClick={() => setActiveTab('inspector')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'inspector'
              ? 'font-semibold text-indigo-600 dark:text-indigo-400'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Inspector
        </button>
        <button
          onClick={() => setActiveTab('vectorizer')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'vectorizer'
              ? 'font-semibold text-indigo-600 dark:text-indigo-400'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Vectorizador
        </button>
        <button
          onClick={() => setActiveTab('laser_matrix')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeTab === 'laser_matrix'
              ? 'font-semibold text-indigo-600 dark:text-indigo-400'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Matriz Láser
        </button>
        <button
          onClick={() => {
            setActiveTab('directory');
            setShowFavoritesOnly(!showFavoritesOnly);
          }}
          className={`px-2.5 py-1 rounded flex items-center gap-1 whitespace-nowrap ${
            showFavoritesOnly
              ? 'font-semibold text-amber-600 dark:text-amber-400'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" />
          <span>({favoritesCount})</span>
        </button>
      </div>
    </header>
  );
};
