export type ToolCategory =
  | 'all'
  | 'editors'
  | 'vectorizers'
  | 'laser_cnc'
  | 'optimizers'
  | 'repositories'
  | 'converters';

export type PlatformType = 'Web (En navegador)' | 'Windows / Mac / Linux' | 'Web y Software';

export type LicenseType = 
  | 'Código Abierto (Open Source)'
  | 'Gratis sin registro'
  | 'Gratis con registro'
  | 'Plan Gratuito Generoso';

export interface VectorTool {
  id: string;
  name: string;
  url: string;
  category: ToolCategory;
  shortDescription: string;
  detailedDescription: string;
  bestFor: string;
  formats: string[];
  platform: PlatformType;
  license: LicenseType;
  requiresRegistration: boolean;
  laserFriendly: boolean;
  featured?: boolean;
  tags: string[];
  tips: string[];
  isCustom?: boolean;
}

export interface CategoryInfo {
  id: ToolCategory;
  label: string;
  description: string;
  count?: number;
}
